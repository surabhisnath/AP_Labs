package Tests;

import static org.junit.Assert.*;
import java.io.IOException;
import org.junit.Test;
import App.*;

public class Testadd
{

	@Test
	public void test() throws IOException, ClassNotFoundException
	{
		App.Playlist p=MusicApp.deserialize("mylist name");
		String one=p.show();
		Song song1=new Song("newsong1","newsinger1",500);
		p.add(song1);
		Song song2=new Song("newsong2","newsinger2",500);
		p.add(song2);
		MusicApp.serialize(p);
		
		assertEquals(one+song1.toString()+song2.toString(),p.show());
	}

}
