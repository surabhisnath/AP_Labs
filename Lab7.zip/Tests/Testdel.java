package Tests;

import static org.junit.Assert.*;
import java.io.IOException;
import App.*;
import org.junit.Test;

public class Testdel 
{
	@Test
	public void test() throws IOException, ClassNotFoundException
	{
		Playlist p=MusicApp.deserialize("mylist name");
		String one=p.show();
		Song song=new Song("newsong2","newsinger2",500);
		p.delete("newsong2");
		MusicApp.serialize(p);

		assertEquals(one,p.show()+song.toString());
	}
}
