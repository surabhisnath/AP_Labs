package Tests;

import static org.junit.Assert.*;
import java.io.IOException;
import App.*;
import org.junit.Test;

public class Testsearch 
{

	@Test
	public void test() throws IOException, ClassNotFoundException
	{
		Playlist p=MusicApp.deserialize("mylist name");	
		Song song1=new Song("newsong1","newsinger1",500);
		String one=song1.toString();

		assertEquals(one,p.search("newsong1"));
	}

}
