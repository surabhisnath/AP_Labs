package App;

import java.io.Serializable;
import java.util.ArrayList;

public class Playlist implements Serializable
{
	ArrayList<Song> list;
	private String playlistname;
	
	
	public Playlist(String n)
	{
		list=new ArrayList<Song>();
		playlistname=n;
	}
	
	public void add(Song song)
	{
		list.add(song);
		//System.out.println("Song added. Number of songs in playlist now: "+list.size());
	}
	
	
	public boolean delete(String songname)
	{
		boolean flag=false;
		for(int i=0; i<list.size(); i++)
		{
			if(list.get(i).getsongname().equals(songname))
			{
				list.remove(i);
				//System.out.println("Song deleted. Number of songs in playlist now: "+list.size());
				flag=true;
				break;
			}
		}
		
		//if(flag==false)
			//System.out.println("ERROR: Song name entered does not exist in playlist");
		return flag;
	}
	
	
	public String search(String songname)
	{
		for(int i=0; i<list.size(); i++)
		{
			if(list.get(i).getsongname().equals(songname))
			{
				return list.get(i).toString();
			}
		}
		
		return "ERROR: Song name entered does not exist in playlist";
	}
	
	public String show()
	{
		if(list.size()==0)
			return "No song exists";
		
		else
		{
			String ans="";
			
			for(int y=0; y<list.size(); y++)
			{
				ans+=list.get(y).toString();
			}
			
			return ans;
		}
	}
	
	public String getplaylistname()
	{
		return playlistname;
	}
}
