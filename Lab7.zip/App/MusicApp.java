package App;

import java.io.*;
import java.util.*;

//interface Serializable {}

class Reader 
{
    static BufferedReader reader;
    static StringTokenizer tokenizer;

    /** call this method to initialize reader for InputStream */
    static void init(InputStream input) {
        reader = new BufferedReader(new InputStreamReader(input));
        tokenizer = new StringTokenizer("");
    }
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
            tokenizer = new StringTokenizer(
                   reader.readLine() );
        }
        return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }
	
    static double nextDouble() throws IOException {
        return Double.parseDouble( next() ); 
    }
    
    static long nextLong() throws IOException {
        return Long.parseLong( next() );
    }
}	


public class MusicApp 
{
	
	public static void serialize(Playlist p) throws IOException 
	{
		ObjectOutputStream out = null;
		try 
		{
			out = new ObjectOutputStream (new FileOutputStream("./src/" + p.getplaylistname() + ".txt"));
			out.writeObject(p);
		}
		
		finally 
		{
			out.close();
		}
	}
	
	
	public static Playlist deserialize(String name) throws IOException, ClassNotFoundException 
	{
		ObjectInputStream in = null;
		try 
		{
			in = new ObjectInputStream (new FileInputStream("./src/" + name + ".txt"));
			Playlist p = (Playlist) in.readObject();
			return p;
		} 
		
		finally 
		{
			in.close();
		}
	}

	public static void main(String[] args) throws IOException, ClassNotFoundException
	{

		Reader.init(System.in);
		Playlist p1 = new Playlist("mylist name");
		p1.add(new Song("s1 hello","singer1 bye",10));
		p1.add(new Song("s2 hello","singer2 bye",20));
		p1.add(new Song("s3 hello","singer3 bye",15));
		p1.add(new Song("s4 hello","singer4 bye",5));
		
		Playlist p2 = new Playlist("mylist name two");
		p2.add(new Song("s1 hello two","singer1 bye",10));
		p2.add(new Song("s2 hello two","singer2 bye",20));
		p2.add(new Song("s3 hello two","singer3 bye",15));
		p2.add(new Song("s4 hello two","singer4 bye",5));
		
		serialize(p1);
		serialize(p2);
		
		
		int op=5;
		
		
		while(op==5)
		{
			int flag=0;
			System.out.println("Enter name of playlist: ");
			String name=Reader.reader.readLine();
			Playlist p=deserialize(name);
			
			while(true)
			{
				System.out.println("1. Add");
				System.out.println("2. Delete");
				System.out.println("3. Search");
				System.out.println("4. Show");
				System.out.println("5. Back to Menu");
				System.out.println("6. Exit");
				
				op=Reader.nextInt();
				
				
				switch(op)
				{
					case 1: System.out.println("Enter song details");
						String nameinput=Reader.reader.readLine();
						String singerinput=Reader.reader.readLine();
						int durinput=Reader.nextInt();
						Song s=new Song(nameinput, singerinput, durinput);
						p.add(s);
						System.out.println("Song added. Number of songs in playlist now: "+p.list.size());
						serialize(p);
						break;
						
					case 2: System.out.println("Enter song name to delete");
						String nametodel=Reader.reader.readLine();
						boolean f=p.delete(nametodel);
						if(f==true)
							System.out.println("Song deleted. Number of songs in playlist now: "+p.list.size());
						else
							System.out.println("ERROR: Song name entered does not exist in playlist");
						serialize(p);
						break;
						
					case 3: System.out.println("Enter song name to search");
						String nametosearch=Reader.reader.readLine();
						System.out.print(p.search(nametosearch));
						break;
					
					case 4: System.out.println(p.show());
						break;
					
					case 5: flag=5; 
						break;
					
					case 6: flag=6; 
						break;
				}
				
				if(flag==5)
					break;
				if(flag==6)
					break;
			}
		}
	}
}

