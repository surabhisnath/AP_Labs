package App;

import java.io.Serializable;

public class Song implements Serializable
{
	private String songname;
	private String singer;
	private int songdur;
	
	public Song(String sn, String s, int sd)
	{
		songname=sn;
		singer=s;
		songdur=sd;
	}
	
	public String getsongname()
	{
		return songname;
	}
	
	public String getsingername()
	{
		return singer;
	}
	
	public int getsongdur()
	{
		return songdur;
	}
	
	@Override
	public String toString()
	{
		return songname+" "+singer+" "+songdur;
	}
}

