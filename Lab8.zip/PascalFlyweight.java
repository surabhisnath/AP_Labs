import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.*;

public class PascalFlyweight extends RecursiveTask<Double>
{
	
	private static volatile Map<String, PascalFlyweight> instances=new HashMap<String, PascalFlyweight>();
	
	public static synchronized PascalFlyweight getInstance(double n, double k)
	{
		String key = n+", "+k;
		if (!instances.containsKey(key)) 
		{
			instances.put(key, new PascalFlyweight(n,k));
		}
		
		return instances.get(key);
	}
	
	public Double compute()
	{
		if(n==0 || k==0 || n==k)
			return (double)1;
		
		PascalFlyweight left=PascalFlyweight.getInstance(n-1,k-1);
		PascalFlyweight right=PascalFlyweight.getInstance(n-1,k);
		
		left.fork();
		return right.compute()+left.join();
	}
	
	private final double n,k;
	
	private PascalFlyweight(double N, double K) 
	{
		n=N;
		k=K;
	}

	public static void main(String[] args) 
	{
			ForkJoinPool pool1 = new ForkJoinPool(1);
			PascalFlyweight oper1 = PascalFlyweight.getInstance(50,40);
			long startTime1=System.currentTimeMillis();
			double answer1 = pool1.invoke(oper1);
			System.out.println(answer1);
			long endTime1=System.currentTimeMillis();
			long totalTime1=endTime1 - startTime1;
			System.out.println(totalTime1);	
	}

}


/* ANALYSIS

1) Using flyweight, works very fast for n upto 2000
 
2) For n=50, k=40,	
	When num of threads=1, time=32ms
	When num of threads=2, time=26ms
	When num of threads=3, time=16ms
	Speedup on using 2 threads instead of 1 = 32/26 = 1.2
	Speedup on using 3 threads instead of 2 = 26/16 = 1.6
	Speedup on using 3 threads instead of 1 = 32/16 = 2.0

3) However, we observe that here, the times mostly increase with increase in num of threads. Perhaps this indicates that the Flyweight design pattern cannot be parallelized in this case, or perhaps the creation of threads is taking time.
	
*/



/* ANALYSIS (Flyweight vs Non Flyweight)

1) For n=30, k=15, when num of threads=2 
	On Flyweight: time=15ms, on Non Flyweight: time=3000
	Speedup = 200

2) For n=40, k=10, when num of threads=3 
	On Flyweight: time=15ms, on Non Flyweight: time=12000
	Speedup = 800
 
*/
 


