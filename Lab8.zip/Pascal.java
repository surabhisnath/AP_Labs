import java.math.BigInteger;
import java.util.concurrent.*;

public class Pascal extends RecursiveTask<Long>
{
	long n,k;
	
	public Pascal(long N, long K)
	{
		n=N;
		k=K;
	}
	
	public Long compute()
	{
		if(n==0 || k==0 || n==k)
			return (long)1;
		
		Pascal left=new Pascal(n-1, k-1);
		Pascal right=new Pascal(n-1,k);
		left.fork();
		return right.compute()+left.join();
	}

	public static void main(String[] args) 
	{
		ForkJoinPool pool=new ForkJoinPool(3);
		Pascal oper=new Pascal(50,10);
		long startTime=System.currentTimeMillis();
		long answer=pool.invoke(oper);
		System.out.println(answer);
		long endTime=System.currentTimeMillis();
		long totalTime=endTime - startTime;
		System.out.println(totalTime);
		
	}

}

/* ANALYSIS

1) Takes a long time for n>40

2) For n=30, k=10,	
	When num of threads=1, time=1057ms
	When num of threads=2, time=670ms
	When num of threads=3, time=585ms
	Speedup on using 2 threads instead of 1 = 1057/670 = 1.57
	Speedup on using 3 threads instead of 2 = 670/585  = 1.14
	Speedup on using 3 threads instead of 1 = 1057/585 = 1.90

3) For n=20, k=10,
	When num of threads=1, time=80ms
	When num of threads=2, time=53ms
	When num of threads=3, time=47ms
	Speedup on using 2 threads instead of 1 = 80/53 = 1.51
	Speedup on using 3 threads instead of 2 = 53/47 = 1.12
	Speedup on using 3 threads instead of 1 = 80/47 = 1.70
*/
	

