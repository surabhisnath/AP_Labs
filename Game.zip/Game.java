//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.InputStreamReader;
//import java.io.PrintWriter;
//import java.nio.charset.StandardCharsets;
//import java.nio.file.Files;
//import java.nio.file.Paths;
//import java.util.*;
//
//
//class Reader 
//{
//    static BufferedReader reader;
//    static StringTokenizer tokenizer;
//
//    /** call this method to initialize reader for InputStream */
//    static void init(InputStream input) {
//        reader = new BufferedReader(new InputStreamReader(input));
//        tokenizer = new StringTokenizer("");
//    }
//    static String next() throws IOException {
//        while ( ! tokenizer.hasMoreTokens() ) {
//            tokenizer = new StringTokenizer(
//                   reader.readLine() );
//        }
//        return tokenizer.nextToken();
//    }
//
//    static int nextInt() throws IOException {
//        return Integer.parseInt( next() );
//    }
//	
//    static double nextDouble() throws IOException {
//        return Double.parseDouble( next() ); 
//    }
//    
//    static long nextLong() throws IOException {
//        return Long.parseLong( next() );
//    }
//}	
//
//class Point
//{
//	double x;
//	double y;
//	
//	public Point(double xcor, double ycor)
//	{
//		x=xcor;
//		y=ycor;
//	}
//}
//
//class Knight
//{
//	private String name;
//	private Point p;
//	Stack<Object> s;
//	private int m;
//	private boolean exists;
//	
//	
//	public Knight(String n, double xcor, double ycor, int num)
//	{
//		name=n;
//		p=new Point(xcor, ycor);
//		s=new Stack<Object>();
//		m=num;
//		exists=true;
//	}
//		
//	public Object getstacktop()
//	{
//		return s.pop();
//	}
//	
//	
//	public void pops(Knight[] ar, double Qx, double Qy, PrintWriter file) throws NonCoordinateException, StackEmptyException, OverlapException, QueenFoundException
//	{
//		
//		if(s.size()==0)
//		{
//			this.exists=false;
//			throw new StackEmptyException("StackEmptyException: Stack Empty Exception");
//		}
//		
//		
//		Object temp=getstacktop();
//		
//		if(temp instanceof Point)
//		{
//			Point t=(Point)temp;
//			
//			double t1=t.x;
//			double t2=t.y;
//			int flag=-1;
//			for(int g=0; g<ar.length; g++)
//			{
//				if(ar[g].exists!=false && ar[g].getpoint().x==t1 && ar[g].getpoint().y==t2)
//				{
//					ar[g].exists=false;
//					flag=g;
//				}
//			}
//			
//			p.x=t.x;
//			p.y=t.y;
//			
//			if(flag>=0)
//				throw new OverlapException("OverlapException: Knights Overlap Exception"+" "+ar[flag].name);
//			
//			if(p.x==Qx && p.y==Qy)
//			{
//				throw new QueenFoundException("QueenFoundException: Queen has been found. Abort!");
//			}
//			
//			else
//			{
//				file.println("No Exception"+" "+p.x+" "+p.y);
//			}
//		}
//		
//		else
//		{
//			throw new NonCoordinateException("NonCoordinateException: Not a coordinate Exception"+" "+temp.toString());
//		}
//	}
//	
//	public String getname()
//	{
//		return name;
//	}
//	
//	public boolean getexists()
//	{
//		return exists;
//	}
//	
//	public Point getpoint()
//	{
//		return p;
//	}
//}
//
//
//class NonCoordinateException extends Exception
//{
//	public NonCoordinateException(String message) 
//	{
//		super(message);
//	}
//}
//
//
//class StackEmptyException extends Exception
//{
//	public StackEmptyException(String message) 
//	{
//		super(message);
//	}
//}
//
//
//class OverlapException extends Exception
//{
//	public OverlapException(String message) 
//	{
//		super(message);
//	}
//}
//
//class QueenFoundException extends Exception
//{
//	public QueenFoundException(String message) 
//	{
//		super(message);
//	}
//}
//
//
//
//
//public class Game 
//{
//
//	public static void main(String[] args) throws IOException, NonCoordinateException, StackEmptyException, OverlapException, QueenFoundException
//	{
//		Reader.init(System.in);
//		System.out.print("Enter number of knights: ");
//		int numknights=Reader.nextInt();
//		//System.out.println();
//		System.out.print("Enter the total number of iterations: ");
//		int numiter=Reader.nextInt();
//		//System.out.println();
//		System.out.print("Enter the coordinates of the queen (x and y): ");
//		
//		double Qxcor,Qycor;
//		
//		Qxcor=Reader.nextDouble();
//		Qycor=Reader.nextDouble();
//		
//		PrintWriter file=new PrintWriter("./src/output.txt","UTF-8");
//		
//		Knight array[]=new Knight[numknights];
//		
//		for(int i=1; i<=numknights; i++)
//		{
//			List<String> lines=Files.readAllLines(Paths.get("C:/Users/Surabhi/Desktop/workspace/Lab6/src/"+i+".txt"), StandardCharsets.UTF_8);
//			String[] words=lines.get(1).split(" ");
//			array[i-1]=new Knight(lines.get(0), Double.parseDouble(words[0]), Double.parseDouble(words[1]), Integer.parseInt(lines.get(2)));
//			
//			for(int j=0; j<Integer.parseInt(lines.get(2)); j++)
//			{
//				String word[]=lines.get(3+j).split(" ");
//				if(word[0].equals("String"))
//				{
//					array[i-1].s.push(word[1]);
//				}
//				
//				else if(word[0].equals("Coordinate"))
//				{
//					array[i-1].s.push(new Point(Double.parseDouble(word[1]), Double.parseDouble(word[2])));
//				}
//				
//				else if(word[0].equals("Integer"))
//				{
//					array[i-1].s.push(Integer.parseInt(word[1]));
//				}
//				
//				else if(word[0].equals("Float"))
//				{
//					array[i-1].s.push(Float.parseFloat(word[1]));
//				}
//			}
//		}
//		
//		Arrays.sort(array, new KnightsCompare());
//		
//		boolean flag=false;
//		
//		for(int k=0; k<numiter; k++)
//		{
//			for(int h=0; h<numknights; h++)
//			{
//
//				if(array[h].getexists()==true)
//				{
//					try
//					{
//						file.println((k+1)+" "+array[h].getname()+" "+array[h].getpoint().x+" "+array[h].getpoint().y);	
//						array[h].pops(array,Qxcor,Qycor, file);
//					}
//					
//					catch(NonCoordinateException e)
//					{
//						file.println(e.getMessage());
//					}
//					
//					catch(StackEmptyException e)
//					{
//						file.println(e.getMessage());
//					}
//					
//					catch(OverlapException e)
//					{
//						file.println(e.getMessage());
//					}
//					
//					catch(QueenFoundException e)
//					{
//						file.println(e.getMessage());
//						flag=true;
//						break;
//					}
//					
//				}
//			}
//			
//			if(flag==true)
//				break;
//		}
//		
//		file.close();
//		
//	}
//}
//
//class KnightsCompare implements Comparator<Knight>
//{
//	@Override
//	public int compare(Knight one, Knight two)
//	{
//		if(one.getname().compareTo(two.getname())>0)
//			return 1;
//		
//		else
//			return -1;
//	}
//}



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;


class Reader 
{
    static BufferedReader reader;
    static StringTokenizer tokenizer;

    /** call this method to initialize reader for InputStream */
    static void init(InputStream input) {
        reader = new BufferedReader(new InputStreamReader(input));
        tokenizer = new StringTokenizer("");
    }
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
            tokenizer = new StringTokenizer(
                   reader.readLine() );
        }
        return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }
	
    static double nextDouble() throws IOException {
        return Double.parseDouble( next() ); 
    }
    
    static long nextLong() throws IOException {
        return Long.parseLong( next() );
    }
}	

class Point
{
	double x;
	double y;
	
	public Point(double xcor, double ycor)
	{
		x=xcor;
		y=ycor;
	}
}

class Knight
{
	private String name;
	private Point p;
	Stack<Object> s;
	private int m;
	private boolean exists;
	
	
	public Knight(String n, double xcor, double ycor, int num)
	{
		name=n;
		p=new Point(xcor, ycor);
		s=new Stack<Object>();
		m=num;
		exists=true;
	}
		
	public Object getstacktop()
	{
		return s.pop();
	}
	
	
	public void pops(Knight[] ar, double Qx, double Qy, PrintWriter file) throws NonCoordinateException, StackEmptyException, OverlapException, QueenFoundException
	{
		
		if(s.size()==0)
		{
			this.exists=false;
			throw new StackEmptyException("StackEmptyException: Stack Empty Exception");
		}
		
		
		Object temp=getstacktop();
		
		if(temp instanceof Point)
		{
			Point t=(Point)temp;
			
			double t1=t.x;
			double t2=t.y;
			int flag=-1;
			for(int g=0; g<ar.length; g++)
			{
				if(ar[g].exists!=false && ar[g].getpoint().x==t1 && ar[g].getpoint().y==t2)
				{
					ar[g].exists=false;
					flag=g;
				}
			}
			
			p.x=t.x;
			p.y=t.y;
			if(flag>=0)
				throw new OverlapException("OverlapException: Knights Overlap Exception"+" "+ar[flag].name);
			
			if(p.x==Qx && p.y==Qy)
			{
				throw new QueenFoundException("QueenFoundException: Queen has been found. Abort!");
			}
			
			else
			{
				file.println("No Exception"+" "+p.x+" "+p.y);
			}
		}
		
		else
		{
			throw new NonCoordinateException("NonCoordinateException: Not a coordinate Exception"+" "+temp.toString());
		}
	}
	
	public String getname()
	{
		return name;
	}
	
	public boolean getexists()
	{
		return exists;
	}
	
	public Point getpoint()
	{
		return p;
	}
}


class NonCoordinateException extends Exception
{
	public NonCoordinateException(String message) 
	{
		super(message);
	}
}


class StackEmptyException extends Exception
{
	public StackEmptyException(String message) 
	{
		super(message);
	}
}


class OverlapException extends Exception
{
	public OverlapException(String message) 
	{
		super(message);
	}
}

class QueenFoundException extends Exception
{
	public QueenFoundException(String message) 
	{
		super(message);
	}
}




public class Game 
{

	public static void main(String[] args) throws IOException, NonCoordinateException, StackEmptyException, OverlapException, QueenFoundException
	{
		Reader.init(System.in);
		System.out.print("Enter number of knights: ");
		int numknights=Reader.nextInt();
		//System.out.println();
		System.out.print("Enter the total number of iterations: ");
		int numiter=Reader.nextInt();
		//System.out.println();
		System.out.print("Enter the coordinates of the queen (x and y): ");
		
		double Qxcor,Qycor;
		
		Qxcor=Reader.nextDouble();
		Qycor=Reader.nextDouble();
		
		PrintWriter file=new PrintWriter("./src/output.txt","UTF-8");
		
		Knight array[]=new Knight[numknights];
		
		for(int i=1; i<=numknights; i++)
		{
			List<String> lines=Files.readAllLines(Paths.get("C:/Users/Surabhi/Desktop/workspace/Lab6/src/"+i+".txt"), StandardCharsets.UTF_8);
			String[] words=lines.get(1).split(" ");
			array[i-1]=new Knight(lines.get(0), Double.parseDouble(words[0]), Double.parseDouble(words[1]), Integer.parseInt(lines.get(2)));
			
			for(int j=0; j<Integer.parseInt(lines.get(2)); j++)
			{
				String word[]=lines.get(3+j).split(" ");
				if(word[0].equals("String"))
				{
					array[i-1].s.push(word[1]);
				}
				
				else if(word[0].equals("Coordinate"))
				{
					array[i-1].s.push(new Point(Double.parseDouble(word[1]), Double.parseDouble(word[2])));
				}
				
				else if(word[0].equals("Integer"))
				{
					array[i-1].s.push(Integer.parseInt(word[1]));
				}
				
				else if(word[0].equals("Float"))
				{
					array[i-1].s.push(Float.parseFloat(word[1]));
				}
			}
		}
		
		Arrays.sort(array, new KnightsCompare());
		
		boolean flag=false;
		
		for(int k=0; k<numiter; k++)
		{
			for(int h=0; h<numknights; h++)
			{

				if(array[h].getexists()==true)
				{
					try
					{
						file.println((k+1)+" "+array[h].getname()+" "+array[h].getpoint().x+" "+array[h].getpoint().y);	
						array[h].pops(array,Qxcor,Qycor, file);
					}
					
					catch(NonCoordinateException e)
					{
						file.println(e.getMessage());
					}
					
					catch(StackEmptyException e)
					{
						file.println(e.getMessage());
					}
					
					catch(OverlapException e)
					{
						file.println(e.getMessage());
					}
					
					catch(QueenFoundException e)
					{
						file.println(e.getMessage());
						flag=true;
						break;
					}
					
				}
			}
			
			if(flag==true)
				break;
		}
		
		file.close();
		
	}
}

class KnightsCompare implements Comparator<Knight>
{
	@Override
	public int compare(Knight one, Knight two)
	{
		if(one.getname().compareTo(two.getname())>0)
			return 1;
		
		else
			return -1;
	}
}

