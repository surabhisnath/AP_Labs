import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.HashMap;

class BSTFilesBuilder {

	public void createBSTFiles(int numStudents, int numTrees) {
		Random rand = new Random();
		for (int i = 1; i <= numTrees; i++) {
		    try {
				PrintWriter w = new PrintWriter("./src/" + i + ".txt", "UTF-8");
				int type = rand.nextInt(3) + 1;
				if(type == 1) {
					w.println("Integer");
					w.println(numStudents);
					for (int j = 1; j <= numStudents; j++) {
						w.print(rand.nextInt(1000));
						w.print(" ");
					}
				}
				else if(type == 2) {
					w.println("Float");
					w.println(numStudents);
					for (int j = 1; j <= numStudents; j++) {
						w.print(rand.nextFloat()*1000);
						w.print(" ");
					}
				}
				else {
					w.println("String");
					w.println(numStudents);
					String alphabet = "abcdefghijklmnopqrstuvwxyz";
					for (int j = 1; j <= numStudents; j++) {
						int len = rand.nextInt(10)+1;
						for (int k = 0; k < len; k++)
							w.print(alphabet.charAt(rand.nextInt(alphabet.length())));
						w.print(" ");
					}
				}
				w.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}



class Reader 
{
    static BufferedReader reader;
    static StringTokenizer tokenizer;

    /** call this method to initialize reader for InputStream */
    static void init(InputStream input) {
        reader = new BufferedReader(new InputStreamReader(input));
        tokenizer = new StringTokenizer("");
    }
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
            tokenizer = new StringTokenizer(
                   reader.readLine() );
        }
        return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }
	
    static double nextDouble() throws IOException {
        return Double.parseDouble( next() ); 
    }
    
    static long nextLong() throws IOException {
        return Long.parseLong( next() );
    }
}	


class node<T extends Comparable<T> >
{
	private T data;
	node<T> right;
	node<T> left;
	
	public node()		//Default constructor
	{
		right=null;
		left=null;
	}
	
	
	public node(T d)		//Parameterized constructor
	{
		data=d;
		right=null;
		left=null;
	}
	
	
	public node<T> getLeft()		//returns the link
	{
		return left;
	}
	
	
	public node<T> getRight()		//returns the link
	{
		return right;
	}
	
	
	public void setLeft(node<T> obj)		//sets the link
	{
		left=obj;
	}
	
	public void setRight(node<T> obj)		//sets the link
	{
		right=obj;
	}
	
	public T getData()		//returns the data
	{
		return data;
	}
	
//	public int comp(node<T> obj)
//	{
//		return this.data.compareTo(obj.getData());
//	}
}




class BST<T extends Comparable<T>>
{
	
	node<T> root;
	ArrayList<T> treestorer;
	
	public BST()
	{
		root=null;
		treestorer=new ArrayList<T>();
	}
	
	public void inorder(node<T> root)
	{
		if(root==null)
			return;
		
		inorder(root.getLeft());
		treestorer.add(root.getData());
		inorder(root.getRight());
	}
	
	public node<T> insert(node<T> p, node<T> root)
	{
		if(root==null)
			root=p;
		else
		{
			int res=(p.getData()).compareTo(root.getData());
			if(res<0)
				root.left=(insert(p,root.getLeft()));
			else
				root.right=(insert(p,root.getRight()));
		}
		return root;
	}
	
}

public class Christmas 
{
	public static void main(String[] args) throws IOException
	{
		
		Reader.init(System.in);
		int numtrees=Reader.nextInt();
		int numstud=Reader.nextInt();
		

		HashMap<Integer, ArrayList<Object>> hmap=new HashMap<Integer, ArrayList<Object>>();
		
		for(int i=1; i<=numstud; i++)
		{
			ArrayList<Object> temp=new ArrayList<Object>();
			hmap.put(i, temp);
		}
 		
		BSTFilesBuilder obj=new BSTFilesBuilder();
		obj.createBSTFiles(numstud, numtrees);
		
		for(int i=1; i<=numtrees; i++)
		{
			List<String> lines=Files.readAllLines(Paths.get("C:/Users/Surabhi/Desktop/workspace/Lab5/src/"+i+".txt"), StandardCharsets.UTF_8);
			
			if((lines.get(0)).equals("String"))
			{
				BST<String> obj1=new BST<String>();
				Iterator<String> it=lines.iterator();
				it.next();
				it.next();
				
				String words[]=it.next().split(" ");
				
				String sum="";
				
				for(int k=0; k<numstud; k++)
				{
					obj1.root=obj1.insert(new node<String>(words[k]), obj1.root);
				}
				
				
				obj1.inorder(obj1.root);
				
				int c=0;
				
				for(int a=0; a<obj1.treestorer.size(); a++)
				{
					sum+=obj1.treestorer.get(a);
					if(((String)obj1.treestorer.get(a)).equals((String)obj1.root.getData()))
						c=a;
				}
				
				ArrayList<Object> temp=hmap.get(c+1);
				temp.add(sum);
				hmap.put(c+1, temp);
				
			}
			
			else if((lines.get(0)).equals("Integer"))
			{
				BST<Integer> obj1=new BST<Integer>();
				Iterator<String> it=lines.iterator();
				it.next();
				it.next();
				
				String words[]=it.next().split(" ");
				
				int sum=0;
				
				for(int k=0; k<numstud; k++)
				{
					obj1.root=obj1.insert(new node<Integer>(Integer.parseInt(words[k])), obj1.root);
					sum+=Integer.parseInt(words[k]);
				}
				
				
				obj1.inorder(obj1.root);
				
				int c=0;
				for(int a=0; a<obj1.treestorer.size(); a++)
				{
					
					if(((Integer)obj1.treestorer.get(a)).equals((Integer)obj1.root.getData()))
						break;
					c++;
				}
				

				ArrayList<Object> temp=hmap.get(c+1);
				temp.add(sum);
				hmap.put(c+1, temp);
			}
			
			else
			{
				BST<Float> obj1=new BST<Float>();
				Iterator<String> it=lines.iterator();
				it.next();
				it.next();
				
				String words[]=it.next().split(" ");
				
				float sum=0;
				
				for(int k=0; k<numstud; k++)
				{
					obj1.root=obj1.insert(new node<Float>(Float.parseFloat(words[k])), obj1.root);
					sum+=Float.parseFloat(words[k]);
				}
				
				
				obj1.inorder(obj1.root);
				
				int c=0;
				for(int a=0; a<obj1.treestorer.size(); a++)
				{
					if(((Float)obj1.treestorer.get(a)).equals((Float)obj1.root.getData()))
						break;
					c++;
				}

				ArrayList<Object> temp=hmap.get(c+1);
				temp.add(sum);
				hmap.put(c+1, temp);
			}
		}
		
		
		PrintWriter file=new PrintWriter("./src/output.txt","UTF-8");
		int numofchoc=0;
		for(int h=1; h<=numstud; h++)
		{
			ArrayList<Object> t=hmap.get(h);
			if(t.size()!=0)
			{
				file.print(h+" ");
				for(int q=0; q<t.size(); q++)
					file.print(t.get(q)+" ");
				file.println();
			}
			
			else
			{
				numofchoc++;
			}
		}
		
		file.println(numofchoc);
		file.close();
	}
}
